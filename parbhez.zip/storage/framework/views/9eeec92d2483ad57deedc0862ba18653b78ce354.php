
<div class="row">
    <div class="col-md-12">
    	<table id="categoryDatatable" class="table table-bordered table-striped">
		    <thead>
		        <tr>
		            <th>Category Name English</th>
		            <th>Category Name Bangla</th>
		            <th>Icon Image</th>
		            <th>Is Selected</th>
		            <th>View Order</th>
		            <th>Status</th>
		            <th>Action</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php if(count($categories) > 0): ?>
		    	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
		            <td>
		            	<span><?php echo e($category->category_name_lang1); ?></span>
		            	<input type="text" name="category_name_lang1" class="form-control" id="categoryNameEn_<?php echo e($category->category_id); ?>" value="<?php echo e($category->category_name_lang1); ?>" style="display: none;">
		            </td>
		            <td>
		            	<span><?php echo e($category->category_name_lang2); ?></span>
		            	<input type="text" name="category_name_lang2" class="form-control" id="categoryNameBn_<?php echo e($category->category_id); ?>" value="<?php echo e($category->category_name_lang2); ?>" style="display: none;">
		        	</td>
		        	<td>
		            	<img src="<?php echo e(URL::to('public/images/category/icon_image')); ?>/<?php echo e($category->icon); ?>" alt="icon_image" height="40px" width="40px">
		            	<div class="help-block with-errors"></div>
		            	<a data-toggle="modal" class="btn btn-primary btn-xs" onclick="editModalUpload()" href="#editModal"> Change</a>
		        	</td>

		        	<td>
     	 				<!-- <label class="label label-warning" style="<?php if($category->is_selected==1): ?> display: none; <?php endif; ?>"> Not Selected</label>
      					<label class="label label-success" style="<?php if($category->is_selected==0): ?> display: none; <?php endif; ?>"> Selected</label> -->
      					<span><?php echo e(Helper::isSelected($category->is_selected)); ?></span>
      					<select name="is_selected" id="is_selected" class="form-control" required="">
                        	<option selected="" disabled="">Select a Type</option>
                        	<option value="1"> Selected</option>
                        	<option value="0"> Not Selected</option>
                        </select>

					</td>
					

		        	<td>
		            	<span><?php echo e($category->view_order); ?></span>
		        	</td>
		        	
		            <td>
	            		<label class="label label-warning" style="<?php if($category->status==1): ?> display: none; <?php endif; ?>">
	            		Inactive
	            		</label>
	            		<label class="label label-success" style="<?php if($category->status==0): ?> display: none; <?php endif; ?>">
	            			active
	            		</label>
		            </td>
		            <td>
			            <a href="javascript:;" class="btn btn-success btn-xs" style="<?php if($category->status == 1): ?> display:none; <?php endif; ?>" onclick="updateStatus('category', 'active', <?php echo e($category->category_id); ?>)">
			            	<i class="fa fa-check-square-o" title="Active"></i>	
			           	</a>
			           	<a href="javascript:;" class="btn btn-warning btn-xs" style="<?php if($category->status == 0): ?> display: none;<?php endif; ?>" onclick="updateStatus('category', 'inactive', <?php echo e($category->category_id); ?>)">
			            	<i class="fa fa-ban" title="Inactive"></i>	
			           	</a>


			           	<a href="javascript:;" class="btn btn-info btn-xs edit-category" id="reference_<?php echo e($category->category_id); ?>">
			            	<i class="fa fa-edit" title="Edit"></i>	
			           	</a>

			           	<a href="javascript:;" class="btn btn-success btn-xs save-update-designation">
			            	<i class="fa fa-save" title="Save"></i>	
			           	</a>
			           	<a href="javascript:;" class="btn btn-primary btn-xs" >
			            	<i class="fa fa-refresh fa-spin" title="Reset"></i>	
			           	</a>
			           	<a href="javascript:;" class="btn btn-danger btn-xs" style="<?php if($category->status == 2): ?> display: none;<?php endif; ?>" onclick="updateStatus('category', 'delete', <?php echo e($category->category_id); ?>)">
			            	<i class="fa fa-trash" title="Delete"></i>	
			           	</a>
		            </td>
		        </tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		       <?php endif; ?>
		    </tbody>
		    <tfoot>
		        <tr>
		            <th>Category Name English</th>
		            <th>Category Name Bangla</th>
		            <th>Icon Image</th>
		            <th>Is Selected</th>
		            <th>View Order</th>
		            <th>Status</th>
		            <th>Action</th>
		        </tr>
		    </tfoot>
		</table>
    </div>
</div>

<script type="text/javascript">
	
  $(document).ready(function(){
		$('#categoryDatatable').DataTable();
	});

  $(".modal-title").html("View Category");
  $(".btn-submit-action").parent().hide();
  function updateStatus(modelReference,action,id)
  {
  		var reference = $("#reference_" + id);
  		if(action == 'delete'){
  			if(!confirm("Do you Want to delete ??")){
  				return false;
  			}
  		}
  		$.ajax({
  			url: "update-status/"+modelReference+"/"+action+"/"+id,
  			method: "GET",
  			dataType: "json",
  			success: function(data){
  				//console.log(data);
  				if(data.success == true){
  					if(action == 'active'){
						reference.prev().show().prev().hide();
  						reference.parent().prev().children().next().show().prev().hide();
  					}else if(action == 'inactive'){
  						reference.prev().hide().prev().show();
  						reference.parent().prev().children().next().hide().prev().show();
  					}else if(action == 'delete'){
  						reference.parent().parent().hide(1000).remove();
  					}
  					$(".box-modal-message").show();
  					$(".messageBodySuccess").slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
  				}else {
  					$(".box-modal-message").show();
  					$(".messageBodyError").slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
  				}
  			},
  			error: function(data){
  					$(".box-modal-message").show();
  					$(".messageBodyError").slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
  			}
  		});
  }

  		$(".edit-category").on('click',function(){

  		});

</script>