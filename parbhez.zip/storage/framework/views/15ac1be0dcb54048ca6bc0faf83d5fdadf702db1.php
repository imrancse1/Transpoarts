<!-- <div class="row">
	<div class="col-md-12">
		<form action="<?php echo e(route('settings.save-category.post')); ?>" method="POST" id="myForm" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<div class="col-md-12">
					<div class="col-md-4">
						<label for="category_name_lang1">Category Name English :</label>
					</div>
					<div class="col-md-8">
						<input type="text" name="category_name_lang1" id="category_name_lang1" class="form-control" placeholder="Ex: Electronics...">
						<div class="help-block with-errors"></div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="col-md-4">
						<label for="category_name_lang2">Category Name Bangla :</label>
					</div>
					<div class="col-md-8">
						<input type="text" name="category_name_lang2" id="category_name_lang2" class="form-control" placeholder="উদাঃ ইলেক্ট্রনিক্স...">
						<div class="help-block with-errors"></div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="col-md-4">
						<label for="featured_image">Featured Image :</label>
					</div>
					<div class="col-md-8">
						<input type="file" name="featured_image" class="form-control">
						<div class="help-block with-errors"></div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="col-md-4">
						<label for="icon">Icon Image :</label>
					</div>
					<div class="col-md-8">
						<input type="file" name="icon" class="form-control">
						<div class="help-block with-errors"></div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="col-md-4">
						<label for="is_selected">Is Selected :</label>
					</div>
					<div class="col-md-8">
						<select name="is_selected" id="is_selected" class="form-control" required="">
                        	<option selected="" disabled="">Select a Type</option>
                        	<option value="1"> Selected</option>
                        	<option value="0"> Not Selected</option>
                        </select>
						<div class="help-block with-errors"></div>
					</div>
				</div>

				<div class="col-md-12">
					<div class="col-md-4">
						<label for="view_order">View Order :</label>
					</div>
					<div class="col-md-8">
						<input type="number" name="view_order" class="form-control">
						<div class="help-block with-errors"></div>
					</div>
				</div>
				
			</div>

		</form>
	</div>
</div>
<script>
	$(".modal-title").html("Add Category");
	$(".btn-submit-action").on('click',function(){
		$("#myForm").submit();
	});

</script> -->




<?php $__env->startSection('extra-css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('public/assets/plugins/smartwizard/css/smart_wizard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('public/assets/plugins/smartwizard/css/smart_wizard_theme_arrows.css')); ?>">

    <style type="text/css">
	    .select2-container--default .select2-selection--single,
		.select2-selection .select2-selection--single {
		  width: 380px;
		}
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
	<section class="content-header">
      <h1>
        Category List
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Category</li>
      </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<!-- Main content -->
<section class="content">
	<!-- Custom Tabs -->
	<div class="nav-tabs-custom">
	    <ul class="nav nav-tabs">
	        <li class="active"><a href="#view-category" data-toggle="tab">View Category</a></li>
	        <li><a href="#add-category" data-toggle="tab">Add Category</a></li>
	        <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
	    </ul>
	    <div class="tab-content">
	        <div class="tab-pane active" id="view-category">
	        	<div class="box box-default">
		        	<div class="box-body">
			            <div class="row">
			                <div class="col-md-12">
			                	<table id="categoryDatatable" class="table table-bordered table-striped">
								    <thead>
								        <tr>
								            <th>Employee Name</th>
								            <th>User Name</th>
								            <th>Email</th>
								            <th>Mobile</th>
								            <th>Designation</th>
								            <th>Status</th>
								            <th>Action</th>
								        </tr>
								    </thead>
								    <tbody>
								    	
								        <tr>
								            <td>yuei7ii</td>
								            <td>
								            	tywuuu
								            </td>
								            <td>
								            	tyyy
								            </td>
								            <td>
								            	63788
								            </td>
								            <td>
								            	yyueuu
								            </td>
								            <td>
							            		<label class="label label-warning">
							            			Inactive
							            		</label>
							            		<label class="label label-success">
							            			Active
							            		</label>
								            </td>
								            <td>
									            <a href="javascript:;" class="btn btn-success btn-xs" style="">
									            	<i class="fa fa-check-square-o" title="Active"></i>	
									           	</a>
									           	<a href="javascript:;" class="btn btn-warning btn-xs" style="">
									            	<i class="fa fa-ban" title="Inactive"></i>	
									           	</a>
									           	<a href="" class="btn btn-info btn-xs" id="">
									            	<i class="fa fa-edit" title="Edit"></i>	
									           	</a>
									           	<a href="javascript:;" class="btn btn-danger btn-xs" style="">
									            	<i class="fa fa-trash" title="Delete"></i>	
									           	</a>
								            </td>
								        </tr>
								        
								    </tbody>
								    <tfoot>
								        <tr>
								            <th>Employee Name</th>
								            <th>User Name</th>
								            <th>Email</th>
								            <th>Contact</th>
								            <th>Designation</th>
								            <th>Station</th>
								            <th>Action</th>
								        </tr>
								    </tfoot>
								</table>
			                </div>
			            </div>
			        </div>
			        <div class="box-footer">
			        </div>
		    	</div>
	        </div>
	        <!-- /.tab-pane -->
	        <div class="tab-pane" id="add-category">
	            <div class="box box-default">
		        	<div class="box-body">
			            <div class="row">
			                <div class="col-md-12">
			                	<form action="<?php echo e(route('settings.save-category.post')); ?>" id="myForm" role="form" data-toggle="validator" method="post" accept-charset="utf-8" novalidate="true" enctype="multipart/form-data">
			                        <!-- SmartWizard html -->
			                        <div id="smartwizard" class="sw-main sw-theme-arrows">
			                            <ul class="nav nav-tabs step-anchor">
			                                <li class="nav-item active"><a href="#step-1" class="nav-link">Step 1<br><small>Basic Information</small></a></li>
			                                <!-- <li class="nav-item"><a href="#step-2" class="nav-link">Step 2<br><small>Address</small></a></li> -->
			                                <!-- <li class="nav-item"><a href="#step-3" class="nav-link">Step 3<br><small>Login Information</small></a></li> -->
			                            </ul>
			                            <div class="sw-container tab-content" style="min-height: 152px;">
			                                <div id="step-1" class="tab-pane step-content" style="display: block;">
			                                    <div id="form-step-0" role="form" data-toggle="validator">
			                                        <div class="form-group">
			                                            <div class="col-md-12">
			                                                <label for="category_name_lang1" class="col-md-2">Category Name English</label>
			                                                <div class="col-sm-4">
			                                                    <input type="text" class="form-control" name="category_name_lang1" id="category_name_lang1" placeholder="Write your Category Name" required="">
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                                <label for="category_name_lang2" class="col-md-2">Category Name Bangla</label>
			                                                <div class="col-sm-4">
			                                                    <input type="text" class="form-control" name="category_name_lang2" id="category_name_lang2" placeholder="Write your Category Name Ban" required="">
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                            </div>
			                                        </div>
			                                        <?php echo e(csrf_field()); ?>

			                                        <div class="form-group">
			                                            <div class="col-md-12">
			                                                <label for="featured_image" class="col-md-2">Featured Image:</label>
			                                                <div class="col-sm-4">
			                                                    <input type="file" class="form-control" name="featured_image" id="featured_image" >
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                                <label for="icon" class="col-md-2">Icon Image:</label>
			                                                <div class="col-sm-4">
			                                                    <input type="file" class="form-control" name="icon" id="icon">
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                            </div>
			                                        </div>
			                                        
			                                        <div class="form-group">
			                                            <div class="col-md-12">
			                                                
			                                                <label for="is_selected" class="col-md-2">is_selected:</label>
			                                                <div class="col-sm-4">
			                                                    <select class="form-control select2" name="is_selected" id="is_selected" required="">
			                                                        <option selected="" disabled="">Please Select a Type</option>
			                                                        <option value="1">Selected</option>
			                                                        <option value="0">Not Selected</option>
			                                                        
			                                                    </select>
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                                 <label for="view_order" class="col-md-2">View Order</label>
			                                                <div class="col-sm-4">
			                                                    <input type="number" class="form-control" name="view_order" id="view_order"  required="">
			                                                    <div class="help-block with-errors"></div>
			                                                </div>
			                                            </div>
			                                        </div>
			                                        
			                                    </div>
			                                </div>
			                                
			                            </div>
			                        </div>
			                    </form>
			                </div>
			            </div>
		            </div>
	            </div>
	        </div>
	        <!-- /.tab-pane -->
	    </div>
	    <!-- /.tab-content -->
	</div>
	<!-- nav-tabs-custom -->
	<!-- SELECT2 EXAMPLE -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="<?php echo e(URL::to('public/assets/plugins/validator/validator.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('public/assets/plugins/smartwizard/js/jquery.smartWizard.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#categoryDatatable')
			.addClass( 'nowrap' )
			.dataTable( {
				responsive: true,
				columnDefs: [
					{ targets: [-1, -3], className: 'dt-body-right' }
				]
			});
		});
	$(document).ready(function(){
		var btnFinish = $('<button></button>').text('Finish')
            .addClass('btn btn-info')
            .on('click', function(){
                if( !$(this).hasClass('disabled')){
                    var elmForm = $("#myForm");
                    if(elmForm){
                        elmForm.validator('validate');
                        var elmErr = elmForm.find('.has-error');
                        if(elmErr && elmErr.length > 0){
                            alert('Oops we still have error in the form');
                            return false;
                        }else{
                            alert('Great! we are ready to submit form');
                            elmForm.submit();
                            return false;
                        }
                    }
                }
            });
        var btnCancel = $('<button></button>').text('Cancel')
            .addClass('btn btn-danger')
            .on('click', function(){
                $('#smartwizard').smartWizard("reset");
                $('#myForm').find("input, textarea").val("");
            });
            // Smart Wizard
        $('#smartwizard').smartWizard({
            selected: 0,
            theme: 'dots',
            transitionEffect:'fade',
            toolbarSettings: {toolbarPosition: 'bottom',
                              toolbarButtonPosition: 'right',
                              toolbarExtraButtons: [btnFinish, btnCancel]
                            },
            anchorSettings: {
                markDoneStep: true, // add done css
                markAllPreviousStepsAsDone: true, // When a step selected by url hash, all previous steps are marked done
                removeDoneStepOnNavigateBack: true, // While navigate back done step after active step will be cleared
                enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
            }
        });
        $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
            var elmForm = $("#form-step-" + stepNumber);
            // stepDirection === 'forward' :- this condition allows to do the form validation
            // only on forward navigation, that makes easy navigation on backwards still do the validation when going next
            if(stepDirection === 'forward' && elmForm){
                elmForm.validator('validate');
                var elmErr = elmForm.children('.has-error');
                if(elmErr && elmErr.length > 0){
                    // Form validation failed
                    return false;
                }
            }
            return true;
        });
        $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection) {
            // Enable finish button only on last step
            if(stepNumber == 3){
                $('.btn-finish').removeClass('disabled');
            }else{
                $('.btn-finish').addClass('disabled');
            }
        });
        //Date picker
        $('.datepicker').datepicker({
          autoclose: true
        });
	});
	function updateStatus(action,url,id)
	{
		var reference = $("#reference_"+id);
		if(action == 'delete'){
			if(!confirm('Do you want to Delete ?')){
				return false;
			}
		}
		$.ajax({
			url: "update-"+url+'-status/'+action+'/'+id,
		    method: "GET",
		    dataType: 'json',
		    success: function(data){
		    	if(data.success == true){
		    		if(action == 'active'){
		    			// reference.
			    		reference.prev().show().prev().hide();
			    		reference.parent().prev().children().next().show().prev().hide();
		    		}else if(action == 'inactive'){
		    			reference.prev().hide().prev().show();
		    			reference.parent().prev().children().next().hide().prev().show();
		    		}else if(action == 'delete'){
		    			reference.parent().parent().hide(1000).remove();
		    		}
		    		
		    		$('.box-body-second').show();
		    		$('.messageBodySuccess').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
		    		$('.box-body-second').slideDown(1000).delay(3000).slideUp(1000);
		    	}else{
		    		$('.box-body-second').show();
		    		$('.messageBodyError').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
		    	}
		    },
		    error: function(data){
		    	$('.box-body-second').show();
		    	$('.messageBodyError').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
		    }
		});
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>