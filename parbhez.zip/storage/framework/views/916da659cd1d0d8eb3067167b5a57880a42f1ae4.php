<!DOCTYPE html>
<html>
<head>
  <title>jQuery UI Autocomplete - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
	 <h4>AutoComplete Api</h4>
	 <div>
	 	<label>Name :</label>
	 	<input type="text" name="search_name" id="search_name">
	 </div>
</body>
</html>

<script type="text/javascript">
	$(document).ready(function(){
		$("#search_name").autocomplete({
			source: '<?php echo URL::route('test.autocomplete'); ?>',
			minLength: 1,
			autoFocus: true,
			select: function(e,ui){
				alert(ui);
				console.log(ui);
			}
		});
	});
</script>