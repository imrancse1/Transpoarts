<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('public/assets/plugins/smartwizard/css/smart_wizard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(URL::to('public/assets/plugins/smartwizard/css/smart_wizard_theme_arrows.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('public/assets/plugins/chosen/css/chosen.min.css')); ?>">
<style type="text/css">
   .select2-container--default .select2-selection--single,
   .select2-selection .select2-selection--single {
   width: 380px;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
   <h1>
      Product List
      <small>Preview</small>
   </h1>
   <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
      <li><a href="#">Forms</a></li>
      <li class="active">Product</li>
   </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<!-- Main content -->
<section class="content">
   <!-- Custom Tabs -->
   <div class="nav-tabs-custom">
      <ul class="nav nav-tabs">
         <li class="active"><a href="#view-info" data-toggle="tab">View Info</a></li>
         <li><a href="#add-info" data-toggle="tab">Add Info</a></li>
         <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
      </ul>
      <div class="tab-content">
         <div class="tab-pane active" id="view-info">
            <div class="box box-default">
               <div class="box-body">
                  <div class="row">
                     <div class="col-md-12">
                        <table id="productDatatable" class="table table-bordered table-striped">
                           <thead>
                              <tr>
                                 <th>SL</th>
                                 <th>Category</th>
                                 <th>Product Name</th>
                                 <th>Image</th>
                                 <th>Price</th>
                                 <th>Discount</th>
                                 <th>Quantity</th>
                                 <th>Comission</th>
                                 <th>Status</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              
                              <tr>
                                 <td>htsrj</td>

                                 <td>htrsj</td>
                                 <td>dhjrjjk</td>
                                 <td> 
                                    jdj
                                    <img src="">
                                 
                                 </td>

                                 <td>ghtsj</td>
                                 <td>ystej</td>
                                 <td>hsrj</td>
                                 <td>hsjr</td>
                                 <td>
                                    <label class="label label-warning" style="">
                                    Inactive
                                    </label>
                                    <label class="label label-success"  style="">
                                    Active
                                    </label>
                                 </td>
                                 <td>
                                    <a href="javascript:;" class="btn btn-success btn-xs" style="" onclick="updateStatus()">
                                    <i class="fa fa-check-square-o" title="Active"></i> 
                                    </a>
                                    <a href="javascript:;" class="btn btn-warning btn-xs" style="" onclick="updateStatus()">
                                    <i class="fa fa-ban" title="Inactive"></i>  
                                    </a>
                                    <a href="javascript:;" class="btn btn-info btn-xs" id="">
                                    <i class="fa fa-edit" title="Edit"></i> 
                                    </a>
                                    <a href="javascript:;" class="btn btn-danger btn-xs" style="" onclick="updateStatus()">
                                    <i class="fa fa-trash" title="Delete"></i>  
                                    </a>
                                 </td>
                              </tr>
                             
                           </tbody>
                           <tfoot>
                              <tr>
                                 <th>SL</th>
                                 <th>Category</th>
                                 <th>Product Name</th>
                                 <th>Image</th>
                                 <th>Price</th>
                                 <th>Discount</th>
                                 <th>Quantity</th>
                                 <th>Comission</th>
                                 <th>Status</th>
                                 <th>Action</th>
                              </tr>
                           </tfoot>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="box-footer">
               </div>
            </div>
         </div>
         <!-- /.tab-pane -->
         <div class="tab-pane" id="add-info">
            <div class="box box-default">
               <div class="box-body">
                  <div class="row">
                     <div class="col-md-12">
                        <form action="<?php echo e(route('test.save-record.post')); ?>" id="myForm" role="form" data-toggle="validator" method="post" accept-charset="utf-8" novalidate="true" enctype="multipart/form-data">
                           <?php echo e(csrf_field()); ?>

                           <!-- SmartWizard html -->
                           <div id="smartwizard" class="sw-main sw-theme-arrows">
                              <ul class="nav nav-tabs step-anchor">
                                 <li class="nav-item active"><a href="#step-1" class="nav-link">Step 1<br><small>Personal Information</small></a></li>
                                 <li class="nav-item"><a href="#step-2" class="nav-link">Step 2<br><small>Job Information</small></a></li>
                                 <li class="nav-item"><a href="#step-3" class="nav-link">Step 3<br><small>Address</small></a></li>
                                 <li class="nav-item"><a href="#step-4" class="nav-link">Step 4<br><small>Extra Information</small></a></li>
                              </ul>
                              <div class="sw-container tab-content" style="min-height: 152px;">
                                 <div id="step-1" class="tab-pane step-content" style="display: block;">
                                    <div id="form-step-0" role="form" data-toggle="validator">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="name" class="col-md-2">Name:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="name" id="name" placeholder="Write your Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="mobile_number" class="col-md-2">Mobile Number :</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="mobile_number" id="mobile_number">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="father_name" class="col-md-2">Father's Name:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="father_name" id="father_name" placeholder="Write your Father Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="f_mobile_number" class="col-md-2">Father's Mobile Number :</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="f_mobile_number" id="f_mobile_number">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>
                                       
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="mother_name" class="col-md-2">Mother's Name:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="mother_name" id="mother_name" placeholder="Write your Mother Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="m_mobile_number" class="col-md-2">Mother's Mobile Number :</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="m_mobile_number" id="m_mobile_number">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="edu_qualification" class="col-md-2">Education Qualification:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="edu_qualification" id="edu_qualification" placeholder="Write your Education Qualification">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="religion" class="col-md-2">Religion :</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="religion" id="religion">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="dob" class="col-md-2">Date Of Birth:</label>
                                             <div class="col-sm-4">
                                                <input class="form-control datepicker" autocomplete="off" type="text" name="dob" id="dob" placeholder="Date Of Birth">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="nation_id" class="col-md-2">National/Birth Certificate Id:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="nation_id" id="nation_id">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="discount" class="col-md-2">Marital Status:</label>

                                             <div class="col-sm-4">
                                                <input type="radio" name="marital_status" class="reference_married" value="1"> &nbsp;Married &nbsp;&nbsp;&nbsp;
                                                <input type="radio" name="marital_status" class="reference_unmarried" value="0"> &nbsp;Unmarried
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="no_of_child" class="col-md-2">No of Child:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control " name="no_of_child" id="no_of_child">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="no_of_child" class="col-md-2" style="display: none;">No of Child:</label>
                                             <div class="col-sm-4" style="display: none;">
                                                <input type="text" class="form-control" value="0" readonly="">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="step-2" class="tab-pane step-content">
                                    <div id="form-step-1" role="form" data-toggle="validator">


                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="card_no" class="col-md-2">Card No:</label>
                                             <div class="col-sm-4">
                                                <input type="text" name="card_no", id="card_no" class="form-control" placeholder="Write your Card No">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="designation" class="col-md-2">Designation:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="designation" id="designation" placeholder="Write your Designation Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="joining_date" class="col-md-2">Joining Date:</label>
                                             <div class="col-sm-4">
                                                <input class="form-control datepicker" autocomplete="off" type="text" name="joining_date" id="joining_date" value="2016-04-27">

                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="section" class="col-md-2">Section:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="section" id="section" placeholder="Write Section Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="job_reference_name" class="col-md-2">Job Reference Name:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="job_reference_name" id="job_reference_name"  placeholder="Job Reference Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="mobile_no" class="col-md-2">Mobile No:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="mobile_no" id="mobile_no">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <h4>Job Experience/EmployMent History :</h4>

                                             <label for="factory_name" class="col-md-2">Factory Name:</label>
                                             <div class="col-sm-4">
                                                <input class="form-control" name="factory_name" id="factory_name" placeholder="Write Factory Name">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="job_exp_designation" class="col-md-2">Designation :</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="job_exp_designation" id="job_exp_designation" placeholder="Write Job Experience Designation">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             
                                             
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             
                                                <label for="job_exp_designation" class="col-md-2">Employment Period  :</label>
                                                
                                                <div class="col-sm-2">
                                                   <?php echo e(csrf_field()); ?>

                                                   <input class="form-control datepicker" autocomplete="off" type="text" name="from" id="from" value="" placeholder="From">
                                                </div>

                                               
                                                <div class="col-sm-2">
                                                    <input class="form-control datepicker" autocomplete="off" type="text" name="to" id="to" value="" placeholder="To">
                                                </div>

                                                <label for="job_experience" class="col-md-2">Total Year of Experience:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="job_experience" id="job_experience" placeholder="Write Job Experience">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>




                                    </div>
                                 </div>
                                 <div id="step-3" class="tab-pane step-content">
                                    <div id="form-step-2" role="form" data-toggle="validator">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <h4>Permanent Address :</h4>
                                             <label for="path" class="col-md-1">Village:</label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="village">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="post_office" class="col-md-1">Post Office: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="post_office" placeholder="Write Post office">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="up_zila" class="col-md-1">P.S/Up-Zila: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="up_zila" placeholder="Write Up Zila ">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="district" class="col-md-1">District: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="district" placeholder="Write District Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                    
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <h4>Present Address :</h4>
                                             <label for="path" class="col-md-1">Word/Road:</label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="p_road" placeholder="Write Road/Word No">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="p_post_office" class="col-md-1">Post Office: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="p_post_office" placeholder="Write Post office">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="p_up_zila" class="col-md-1">P.S/Up-Zila: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="p_up_zila" placeholder="Write Up Zila ">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="p_district" class="col-md-1">District: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="p_district" placeholder="Write District Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                    
                                          </div>
                                       </div>

                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <h4>Emergency Communication Address :</h4>
                                             <label for="e_village" class="col-md-1">Village/Road:</label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="e_village">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="e_post_office" class="col-md-1">Post Office: </label>
                                             <div class="col-sm-1">
                                                <input type="text" class="form-control" name="e_post_office">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="e_up_zila" class="col-md-1">P.S/Up-Zila: </label>
                                             <div class="col-sm-1">
                                                <input type="text" class="form-control" name="e_up_zila">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="e_district" class="col-md-1">District: </label>
                                             <div class="col-sm-1">
                                                <input type="text" class="form-control" name="e_district">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="e_mobile" class="col-md-1">Mobile No: </label>
                                             <div class="col-sm-2">
                                                <input type="text" class="form-control" name="e_mobile">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                    
                                          </div>
                                       </div>
                                       
                                    </div>
                                 </div>

                                 <div id="step-4" class="tab-pane step-content">
                                    <div id="form-step-3" role="form" data-toggle="validator">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="c_name" class="col-md-2">Local Chairman Name:</label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="c_name" placeholder="Write Chairman Name">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                             <label for="c_mobile" class="col-md-2">Mobile No: </label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="c_mobile" placeholder="Write Chairman Mobile No">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="m_mobile" class="col-md-2">Word Member Name: </label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="m_mobile" placeholder="Write Member Mobile No">
                                                <div class="help-block with-errors"></div>
                                             </div>

                                             <label for="m_mobile" class="col-md-2">Mobile No: </label>
                                             <div class="col-sm-4">
                                                <input type="text" class="form-control" name="m_mobile" placeholder="Write Member Mobile No">
                                                <div class="help-block with-errors"></div>
                                             </div>
                                          </div>
                                       </div>

                                        <div class="form-group">
                                          <div class="col-md-12">
                                             <label for="allegation_thana" class="col-md-3">Is There Any Allegation in Thana:</label>
                                             <div class="col-sm-4">
                                               <input type="radio" name="yes" value="1" class="reference">&nbsp;Yes&nbsp;&nbsp;&nbsp;
                                               <input type="radio" name="no" value="0">&nbsp;No
                                               <div class="help-block with-errors"></div>
                                             </div>
                                                <label for="c_name" class="col-md-2" style="display: none;">If  Yes Give Reason:</label>
                                             <div class="col-sm-4" style="display: none;">
                                                <input type="text" name="" class="form-control" placeholder="If  Yes Give Reason">
                                                <div class="help-block with-errors"></div>

                                                </div>
                                             </div>
                                             </div>
                                             
                                             
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- /.tab-pane -->
      </div>
      <!-- /.tab-content -->
   </div>
   <!-- nav-tabs-custom -->
   <!-- SELECT2 EXAMPLE -->
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
<script src="<?php echo e(URL::to('public/assets/plugins/validator/validator.min.js')); ?>"></script>
<script src="<?php echo e(URL::to('public/assets/plugins/smartwizard/js/jquery.smartWizard.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::to('public/assets/plugins/chosen/js/chosen.jquery.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">
   $(document).ready(function(){
    $('#productDatatable')
        .addClass( 'nowrap' )
        .dataTable( {
            responsive: true,
            columnDefs: [
                { targets: [-1, -3], className: 'dt-body-right' }
            ]
        });
    });

   //Extra-info Radio Button
   $(".reference_married").on('click',function(){
      $(this).parent().next().show().next().show().next().hide().next().hide();
   });

   //Extra-info Radio Button
   $(".reference_unmarried").on('click',function(){
    $(this).parent().next().hide().next().hide().next().show().next().show();
   });

   $(document).ready(function(){
    var btnFinish = $('<button></button>').text('Finish')
              .addClass('btn btn-info')
              .on('click', function(){
                  if( !$(this).hasClass('disabled')){
                      var elmForm = $("#myForm");
                      if(elmForm){
                          elmForm.validator('validate');
                          var elmErr = elmForm.find('.has-error');
                          if(elmErr && elmErr.length > 0){
                              alert('Oops we still have error in the form');
                              return false;
                          }else{
                              alert('Great! we are ready to submit form');
                              elmForm.submit();
                              return false;
                          }
                      }
                  }
              });
          var btnCancel = $('<button></button>').text('Cancel')
              .addClass('btn btn-danger')
              .on('click', function(){
                  $('#smartwizard').smartWizard("reset");
                  $('#myForm').find("input, textarea").val("");
              });
              // Smart Wizard
          $('#smartwizard').smartWizard({
              selected: 0,
              theme: 'dots',
              transitionEffect:'fade',
              toolbarSettings: {toolbarPosition: 'bottom',
                                toolbarButtonPosition: 'right',
                                toolbarExtraButtons: [btnFinish, btnCancel]
                              },
              anchorSettings: {
                  markDoneStep: true, // add done css
                  markAllPreviousStepsAsDone: true, // When a step selected by url hash, all previous steps are marked done
                  removeDoneStepOnNavigateBack: true, // While navigate back done step after active step will be cleared
                  enableAnchorOnDoneStep: true // Enable/Disable the done steps navigation
              }
          });
          $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
              var elmForm = $("#form-step-" + stepNumber);
              // stepDirection === 'forward' :- this condition allows to do the form validation
              // only on forward navigation, that makes easy navigation on backwards still do the validation when going next
              if(stepDirection === 'forward' && elmForm){
                  elmForm.validator('validate');
                  var elmErr = elmForm.children('.has-error');
                  if(elmErr && elmErr.length > 0){
                      // Form validation failed
                      return false;
                  }
              }
              return true;
          });
          $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection) {
              // Enable finish button only on last step
              if(stepNumber == 3){
                  $('.btn-finish').removeClass('disabled');
              }else{
                  $('.btn-finish').addClass('disabled');
              }
          });
          //Date picker
          $('.datepicker').datepicker({
            autoclose: true,
            //format:'yyyy-mm-dd'
          });
   });
   
   //Creating Multi Select Box using Select2 jQuery
   $(document).ready(function(){
      $(".chosen-select").chosen({
          disable_search_threshold: 10,
          no_results_text: "Oops, nothing found!",
          //placeholder_text_multiple: "Select Some Options",
          allow_single_deselect: true,
          width: "100%"
  });
   });
   //Add More Image Javascript
    $(".btn-add-image").on('click', function(){
        var content =  '<div class="form-group">'+
                            '<div class="col-md-12">'+
                                  '<label for="path" class="col-md-2">Prouduct Image:</label>' +
                                  '<div class="col-sm-4">' +
                                      '<input type="file" class="form-control" name="path[]" required="">' +
                                      '<div class="help-block with-errors"></div>' +
                                  '</div>' +
                                  '<label for="caption" class="col-md-2">Image Title: </label>' +
                                  '<div class="col-sm-3">' +
                                      '<input type="text" class="form-control" name="caption[]" placeholder="Write Image Title" required="">' +
                                      '<div class="help-block with-errors"></div>' +
                                  '</div>' +
                                  '<div class="col-sm-1">' +
                                    '<a href="javascript:;" class="btn btn-xs btn-danger btn-remove-image" title="Remove Image">' + 
                                        '<i class="fa fa-minus"></i>' +
                                    '</a>' +
                                  '</div>' +  
                              '</div>' +
                          '</div>';
              $(".load-dynamic-image-content").append(content);
              $(".btn-remove-image").on('click', function(){
                $(this).parent().parent().parent().remove();
                //$(this).parent().prev().prev().prev().prev().parent().parent().remove();
              });            
    });
   
   
   
   
   function updateStatus(action,url,id)
   {
    var reference = $("#reference_"+id);
    if(action == 'delete'){
        if(!confirm('Do you want to Delete ?')){
            return false;
        }
    }
    $.ajax({
        url: "update-"+url+'-status/'+action+'/'+id,
        method: "GET",
        dataType: 'json',
        success: function(data){
            if(data.success == true){
                if(action == 'active'){
                    // reference.
                    reference.prev().show().prev().hide();
                    reference.parent().prev().children().next().show().prev().hide();
                }else if(action == 'inactive'){
                    reference.prev().hide().prev().show();
                    reference.parent().prev().children().next().hide().prev().show();
                }else if(action == 'delete'){
                    reference.parent().parent().hide(1000).remove();
                }
                
                $('.box-body-second').show();
                $('.messageBodySuccess').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
                $('.box-body-second').slideDown(1000).delay(3000).slideUp(1000);
            }else{
                $('.box-body-second').show();
                $('.messageBodyError').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
            }
        },
        error: function(data){
            $('.box-body-second').show();
            $('.messageBodyError').slideDown(1000).delay(3000).slideUp(1000).children().next().html(data.message);
        }
    });
   }

   //Get Category Wise Sub Category
   $("#category_id").on('change',function(){
      var categoryId = $(this).val();
      var subCategoryId = $("#sub_category_id");

      $.ajax({
         url: 'categoryWiseSubCategory/' + categoryId,
         method : "GET",
         dataType : "json",
         success: function(data){
            //console.log(data);
            subCategoryId.empty();
            var content = '<option selected="" disabled="">Please Select a Sub Category</option>';
            $.each(data, function(index,value){
               //console.log(value);
               content += '<option value="'+value.sub_category_id+'">'+value.sub_category_name_lang1+'</option>';
            });
            subCategoryId.append(content);
         },
         error:function(){
            alert("Something Went Wrong");
         }

      });
   });

   //Get Sub Category Wise Sub Sub Category Details
   $("#sub_category_id").on('change',function(){
      var subCategoryId = $(this).val();
      var subSubCategoryId = $("#sub_sub_category_id");
      //alert(subCategoryId);

      $.ajax({
         url : 'subCategoryWiseSubSubCategory/' +subCategoryId,
         method : "GET",
         dataType : "json",

         success:function(data){
            //console.log(data);
            subSubCategoryId.empty();
            var content = '<option selected="" disabled="">Please Select a Sub Sub Category</option>';
            $.each(data,function(index, value){
                  content+='<option value="'+value.sub_sub_category_id+'">'+value.sub_sub_category_name_lang1+'</option>';
            });
            subSubCategoryId.append(content);
         },
         error:function(){
            alert("Something Went Wrong");
         }
      });
   });

   //Market price-discount-Sale Price
   $(".market_price_discount").on('keyup', function(){
      var market_price = $("#market_price").val();
      var discount = $("#discount").val();

      if(!market_price){
         return false;
      }
      if(!discount){
         discount = 0;
      }
      var net_sale_price = market_price - discount;
      $("#sale_price").val(net_sale_price);
   });

   //Commission
   $(".product_commission").on('keyup', function(){
      var productCommission = $("#commission").val();
      var salePrice = $("#sale_price").val();
      
      if(!salePrice){
         return false;
      }else {
         var commission = (salePrice * productCommission)/100;
         $(".eshopping_commission").val(commission);
      }
   });

  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>