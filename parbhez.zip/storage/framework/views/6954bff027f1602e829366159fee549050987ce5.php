<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="generator" content="CoffeeCup HTML Editor (www.coffeecup.com)">
    <meta name="dcterms.created" content="Tue, 24 Sep 2019 11:31:09 GMT">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>Records</title>
   <!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <!--[if IE]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<style>
   #main {
  width: 700px;
  margin: 0 auto; 
}
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div style=" text-align: center;" id="main">
        <!-- <table width="100%" border="1" cellpadding="2" cellspacing="2"> -->
        <h3>Personal Records</h3>
        <table class="center">
            <tr valign="top">
                <td>Name:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Mobile No :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Father's Name:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Mobile No :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Mother's Name:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Mobile No :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Education Qualification:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Religion :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Date Of Birth:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>National/Birth Certificate Id :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Marital Status:</td>
                <td>
                    <input type="radio" name="gender" value="male"> Married
                    <input type="radio" name="gender" value="female"> Unmarried
                </td>
                <td>No Child</td>
                <td>
                    <input type="" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Card No:</td>
                <td>
                    <input type="" name="">
                </td>
                <td>Designation:</td>
                <td>
                    <input type="" name="">
                </td><br>
                <td>Joining Date:</td>
                <td>
                    <input type="date" name="">
                </td>
                <td>Section:</td>
                <td>
                    <input type="" name="">
                </td>
            </tr>

            <tr valign="top">
                <td>Job Reference Name :</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Mobile No :</td>
                <td>
                    <input type="text" name="">
                </td>
            </tr>
        </table>

        <table>
             <tr valign="top">
                <td style="font-size: 20px; font-style: bold;">Job Experience -</td>
            </tr>

            <tr valign="top">
               <td>Factory Name:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Designation:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>Period:</td>
                <td>
                    <input type="text" name="">
                </td>
           </tr>

           <tr valign="top">
                <td style="font-size: 20px; font-style: bold;">Permanent Address -</td>
            </tr>
            
            <tr valign="top">
               <td>Vallage:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Post Office:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>PS/Up-Zila:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>District:</td>
                <td>
                    <input type="text" name="">
                </td>
           </tr>

           <tr valign="top">
                <td style="font-size: 20px; font-style: bold;">Present Address -</td>
            </tr>
            
            <tr valign="top">
               <td>Word/Road:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Post Office:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>PS/Up-Zila:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>District:</td>
                <td>
                    <input type="text" name="">
                </td>
           </tr>

           <tr valign="top">
                <td style="font-size: 20px; font-style: bold;">Emmergency Communication Address -</td>
            </tr>
            
            <tr valign="top">
               <td>Village:</td>
                <td>
                    <input type="text" name="">
                </td>

                <td>Post Office:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>PS/Up-Zila:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>District:</td>
                <td>
                    <input type="text" name="">
                </td>
                <td>Mobile No:</td>
                <td>
                    <input type="text" name="">
                </td>
           </tr>

           <tr>
               <td>Local Chairman Name:</td>
               <td>
                   <input type="" name="">
               </td>

               <td>Mobile No:</td>
               <td>
                   <input type="" name="">
               </td>
           </tr>

           <tr>
               <td>Word Chairman Name:</td>
               <td>
                   <input type="" name="">
               </td>

               <td>Mobile No:</td>
               <td>
                   <input type="" name="">
               </td>
           </tr>

           <tr>
               <td>Is There Any Allegation in Thana:</td>
               <td>
                  <input type="radio" name="gender" value="male"> Yes
                  <input type="radio" name="gender" value="female"> No
               </td>

               <td>If Yes Give Reason</td>
              <td>
                   <textarea rows="2"></textarea>
              </td>
               
           </tr>
        </table>
    </div>

            </div>
        </div>
    </div>
    
</body>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

</html>