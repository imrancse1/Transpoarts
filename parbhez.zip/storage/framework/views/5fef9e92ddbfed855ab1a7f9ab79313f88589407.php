<!-- jQuery 3 -->
<?php echo e(Html::script('public/assets/bower_components/jquery/dist/jquery.min.js')); ?>

<!-- jQuery UI 1.11.4 -->
<?php echo e(Html::script('public/assets/bower_components/jquery-ui/jquery-ui.min.js')); ?>

<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<?php echo e(Html::script('public/assets/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>

<!-- Morris.js charts -->
<?php echo e(Html::script('public/assets/bower_components/raphael/raphael.min.js')); ?>

<?php echo e(Html::script('public/assets/bower_components/morris.js/morris.min.js')); ?>

<!-- Sparkline -->
<?php echo e(Html::script('public/assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')); ?>

<!-- jvectormap -->
<?php echo e(Html::script('public/assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>

<?php echo e(Html::script('public/assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>

<!-- jQuery Knob Chart -->
<?php echo e(Html::script('public/assets/bower_components/jquery-knob/dist/jquery.knob.min.js')); ?>

<!-- daterangepicker -->
<?php echo e(Html::script('public/assets/bower_components/moment/min/moment.min.js')); ?>

<?php echo e(Html::script('public/assets/bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>

<!-- datepicker -->
<?php echo e(Html::script('public/assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>

<!-- Bootstrap WYSIHTML5 -->
<?php echo e(Html::script('public/assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>

<!-- Slimscroll -->
<?php echo e(Html::script('public/assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>

<!-- FastClick -->
<?php echo e(Html::script('public/assets/bower_components/fastclick/lib/fastclick.js')); ?>

<!-- AdminLTE App -->
<?php echo e(Html::script('public/assets/dist/js/adminlte.min.js')); ?>

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<?php echo e(Html::script('public/assets/dist/js/pages/dashboard.js')); ?>

<!-- AdminLTE for demo purposes -->
<?php echo e(Html::script('public/assets/dist/js/demo.js')); ?>

</body>
</html>
