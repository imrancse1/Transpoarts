<?php

namespace App\Backend\Models\Settings;

use Illuminate\Database\Eloquent\Model;

class Size extends Model
{
	
}
