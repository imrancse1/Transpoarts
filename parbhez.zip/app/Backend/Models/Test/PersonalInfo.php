<?php

namespace App\Backend\Models\Test;

use Illuminate\Database\Eloquent\Model;

class PersonalInfo extends Model
{
	protected $connection = 'mysql2';
	protected $primaryKey = 'personal_info_id';
	protected $table= 'personal_infos';

	
}