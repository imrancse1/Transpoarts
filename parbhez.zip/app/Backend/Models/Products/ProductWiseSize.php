<?php

namespace App\Backend\Models\Products;

use Illuminate\Database\Eloquent\Model;

class ProductWiseSize extends Model
{
	protected $primaryKey = 'product_wise_size_id';
	protected $table= 'product_wise_size';
	
    
}
