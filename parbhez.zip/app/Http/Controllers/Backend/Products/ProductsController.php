<?php

namespace App\Http\Controllers\Backend\Products;

use Illuminate\Http\Request;
use App\Http\Requests\ProductRequest;
use App\Http\Controllers\Controller;
use App\Backend\Models\Settings\Category;
use App\Backend\Models\Settings\SubCategory;
use App\Backend\Models\Settings\SubSubCategory;
use App\Backend\Models\Settings\Color;
use App\Backend\Models\Settings\Size;
use App\Backend\Models\Settings\City;
use App\Backend\Models\Products\Product;
use App\Backend\Models\Products\ProductWiseColor;
use App\Backend\Models\Products\ProductWiseSize;
use App\Backend\Models\Products\ProductWiseImage;
use App\Custom\Helper;
use Session;
use DB;

class ProductsController extends Controller
{
    public $view_page_url;
    public function __construct()
    {
        $this->view_page_url = 'Backend.products.';
    }
    public function addProduct()
    {
    	$categories = ['' => 'Please Select a Category'] +
    				Category::where('status', 1)
    				->pluck('category_name_lang1','category_id')
    				->all();

        $colors = Color::where('status',1)->get();
        $sizes = Size::where('status',1)->get();						

        //view data code
        $products = Product::whereIn('status', [0,1])->get();
        //$categories = Category::whereIn('status', [0,1])->get()->first();
        //parent to child tble access
       // foreach ($categories->products as $value) {
       //      dd($value);
       //  } 
       // exit();
        return view($this->view_page_url.'product',compact('categories','colors','sizes','products'));
    }

    public function categoryWiseSubCategoryList($categoryId)
    {
    	return SubCategory::where('category_id',$categoryId)->get();
    }

    public function subCategoryWiseSubSubCategoryList($subCategoryId)
    {
    	return SubSubCategory::where('sub_category_id',$subCategoryId)->get();
    }

    public function saveProduct(ProductRequest $request)
    {
        //return $request->file('path');
        //return $request->all();
        // $p = $request->color_id;
        // echo '<pre>';
        // print_r($p);
        // echo '</pre>';
        // exit();

        $slug = $request->product_name_lang1;
        $productSlug = str_slug($slug,'-');
    	try{
    		DB::beginTransaction();
    		$saveProduct = Product::insertGetId([
    			'category_id'        => $request->category_id,
    			'sub_category_id'    => $request->sub_category_id,
    			'sub_sub_category_id'=> $request->sub_sub_category_id,
    			'product_name_lang1' => $request->product_name_lang1,
    			'product_name_lang2' => $request->product_name_lang2,
    			'market_price'       => $request->market_price,
    			'discount'		     => $request->discount,
                'slug'               => $productSlug,
    			'sale_price'		 => $request->sale_price,
    			'quantity'			 => $request->quantity,
    			'product_code'       => $request->product_code,
    			'details_lang1'      => $request->details_lang1,
                'details_lang2'      => $request->details_lang2,
    			'placement_type'     => $request->placement_type,
                'commission'         => $request->commission, 
    			'created_at'         => date('Y-m-d H:i:s')
    			]);
    			//create a row size
    		if($saveProduct){
    		    foreach ($request->color_id as $color) {
                      $saveColor = ProductWiseColor::insertGetId([
                            'product_id' => $saveProduct,
                            'color_id'   => $color,
                            'created_at' => date('Y-m-d H:i:s'),
                            'created_by' => 1
                    ]);
                }

               

                foreach ($request->size_id as $size) {
                    $saveSize = ProductWiseSize::insertGetId([
                        'product_id' => $saveProduct,
                        'size_id'   => $size,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => 1
                    ]);
                } 
    			
 
                foreach ($request->caption as $caption) {
                    $productWiseImageId = ProductWiseImage::insertGetId([
                                'product_id' =>$saveProduct,
                                'caption' => $caption,
                                'created_at' => date('Y-m-d H:i:s'),
                                'created_by' => 1

                            ]);
                
                }

                if($productWiseImageId){
                    if(count($request->file('path')) > 0){
                        foreach ($request->file('path') as $path) {
                        $folderPath = 'images/product/';
                        $fileName = Helper::imageUploadRaw($saveProduct,$path,$folderPath,211,848);

                        if($fileName != null ){
                            ProductWiseImage::where('product_id',$saveProduct)
                            ->update([
                                'path' => $fileName,
                                'updated_by' => 1
                            ]);
                        }
                    }    
                 }   
                }
            

    		DB::commit();
    		Session::flash('success', 'Product Added Successfully !!');
    	}else{
    		DB::rollback();
    		Session::flash('error', 'Something Went Wrong');
    	}		
    	}catch(\Exception $e){
    		DB::rollback();
    		return $e;
    		Session::flash('error', $e->errorInfo[2]);
    	}
    	return redirect()->route('products.product');

    }
}
