<?php

Route::group(['prefix' => 'products', 'middleware' => 'adminAuth'], function(){
	Route::get('/product', [
		'as' => 'products.product',
		'uses' => 'ProductsController@addProduct'
	]);

	Route::get('/categoryWiseSubCategory/{categoryId}', [
		'as' => 'products.categoryWiseSubCategory',
		'uses' => 'ProductsController@categoryWiseSubCategoryList'
	]);

	Route::get('/subCategoryWiseSubSubCategory/{subCategoryId}',[
		'as' => 'products.subCategoryWiseSubSubCategory',
		'uses' => 'ProductsController@subCategoryWiseSubSubCategoryList'
	]);

	Route::post('/save-product', [
		'as' => 'products.save-product.post',
		'uses' => 'ProductsController@saveProduct'

	]);

});